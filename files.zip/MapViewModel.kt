package com.example.arcgisapp

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arcgismaps.data.Feature
import com.arcgismaps.data.FeatureCollection
import com.arcgismaps.data.FeatureCollectionTable
import com.arcgismaps.geometry.GeometryType
import com.arcgismaps.geometry.Point
import com.arcgismaps.geometry.Polygon
import com.arcgismaps.geometry.Polyline
import com.arcgismaps.geometry.SpatialReference
import com.arcgismaps.mapping.ArcGISMap
import com.arcgismaps.mapping.Basemap
import com.arcgismaps.mapping.Viewpoint
import com.arcgismaps.mapping.layers.FeatureCollectionLayer
import com.arcgismaps.mapping.layers.RasterLayer
import com.arcgismaps.raster.Raster
import com.arcgismaps.data.Field
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

// Data classes for feature details
data class PointDetails(
    val name: String,
    val x: Double,
    val y: Double,
    val spatialReference: String
)

data class LineDetails(
    val name: String,
    val length: Double,
    val pointCount: Int
)

data class PolygonDetails(
    val name: String,
    val area: Double,
    val perimeter: Double
)

class MapViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext

    // Selected feature state
    private val _selectedPoint = MutableStateFlow<PointDetails?>(null)
    val selectedPoint: StateFlow<PointDetails?> = _selectedPoint.asStateFlow()

    private val _selectedLine = MutableStateFlow<LineDetails?>(null)
    val selectedLine: StateFlow<LineDetails?> = _selectedLine.asStateFlow()

    private val _selectedPolygon = MutableStateFlow<PolygonDetails?>(null)
    val selectedPolygon: StateFlow<PolygonDetails?> = _selectedPolygon.asStateFlow()

    // ---------------- Feature Collections ----------------

    val pointTable = FeatureCollectionTable(
        listOf(Field.createText("name", "Name", 50)),
        GeometryType.Point,
        SpatialReference.wgs84()
    )

    val lineTable = FeatureCollectionTable(
        listOf(Field.createText("name", "Name", 50)),
        GeometryType.Polyline,
        SpatialReference.wgs84()
    )

    val polygonTable = FeatureCollectionTable(
        listOf(Field.createText("name", "Name", 50)),
        GeometryType.Polygon,
        SpatialReference.wgs84()
    )

    private val pointCollection = FeatureCollection(listOf(pointTable))
    private val lineCollection = FeatureCollection(listOf(lineTable))
    private val polygonCollection = FeatureCollection(listOf(polygonTable))

    val pointLayer = FeatureCollectionLayer(pointCollection).apply { 
        name = "Points"
        isIdentifyEnabled = true
    }
    val lineLayer = FeatureCollectionLayer(lineCollection).apply { 
        name = "Lines"
        isIdentifyEnabled = true
    }
    val polygonLayer = FeatureCollectionLayer(polygonCollection).apply { 
        name = "Polygons"
        isIdentifyEnabled = true
    }

    // ---------------- Raster Layers ----------------

    private val baseRaster by lazy {
        Raster(copyGeoTifFromAssets(appContext, "0basemap.tif"))
    }

    private val overlayRaster by lazy {
        Raster(copyGeoTifFromAssets(appContext, "raster1.tif"))
    }

    val baseRasterLayer by lazy { RasterLayer(baseRaster) }
    val overlayRasterLayer by lazy { RasterLayer(overlayRaster) }

    // ---------------- ArcGIS Map ----------------

    val arcGISMap by lazy {
        ArcGISMap(SpatialReference.wgs84()).apply {
            basemap = Basemap(baseRasterLayer)
            minScale = 50000000.0
            
            // Layer order: bottom to top
            operationalLayers.addAll(
                listOf(
                    overlayRasterLayer,  // Bottom
                    polygonLayer,        // Middle
                    lineLayer,           // Middle-top
                    pointLayer          // Top (appears on top)
                )
            )
            
            initialViewpoint = Viewpoint(
                Point(71.117965115372, 27.383511873012907, SpatialReference.wgs84()),
                20000.0
            )
        }
    }

    init {
        viewModelScope.launch {
            pointTable.load().onSuccess {
                println("Point table loaded successfully")
            }.onFailure {
                println("Point table load failed: ${it.message}")
            }
            
            lineTable.load().onSuccess {
                println("Line table loaded successfully")
            }.onFailure {
                println("Line table load failed: ${it.message}")
            }
            
            polygonTable.load().onSuccess {
                println("Polygon table loaded successfully")
            }.onFailure {
                println("Polygon table load failed: ${it.message}")
            }
        }
    }

    // ---------------- Add Geometries ----------------

    suspend fun addPointFromGeometry(point: Point, name: String = "Point"): Feature? {
        return try {
            val feature = pointTable.createFeature(mapOf("name" to name), point)
            val result = pointTable.addFeature(feature)
            
            result.onSuccess {
                println("Point added: $name at (${point.x}, ${point.y})")
            }.onFailure { error ->
                println("Failed to add point: ${error.message}")
            }
            
            if (result.isSuccess) feature else null
        } catch (e: Exception) {
            println("Exception adding point: ${e.message}")
            null
        }
    }

    suspend fun addLineFromGeometry(line: Polyline, name: String = "Line"): Feature? {
        return try {
            val feature = lineTable.createFeature(mapOf("name" to name), line)
            val result = lineTable.addFeature(feature)
            
            result.onSuccess {
                println("Line added: $name with ${line.parts.size} parts")
            }.onFailure { error ->
                println("Failed to add line: ${error.message}")
            }
            
            if (result.isSuccess) feature else null
        } catch (e: Exception) {
            println("Exception adding line: ${e.message}")
            null
        }
    }

    suspend fun addPolygonFromGeometry(polygon: Polygon, name: String = "Polygon"): Feature? {
        return try {
            val feature = polygonTable.createFeature(mapOf("name" to name), polygon)
            val result = polygonTable.addFeature(feature)
            
            result.onSuccess {
                println("Polygon added: $name with ${polygon.parts.size} parts")
            }.onFailure { error ->
                println("Failed to add polygon: ${error.message}")
            }
            
            if (result.isSuccess) feature else null
        } catch (e: Exception) {
            println("Exception adding polygon: ${e.message}")
            null
        }
    }

    // ---------------- Feature Selection ----------------

    fun selectPointFromFeature(feature: Feature) {
        viewModelScope.launch {
            try {
                val geometry = feature.geometry as? Point
                val name = feature.attributes["name"] as? String ?: "Unknown Point"
                
                if (geometry != null) {
                    val srName = geometry.spatialReference?.let {
                        if (it.wkid == 4326) "WGS84 (EPSG:4326)"
                        else "WKID: ${it.wkid}"
                    } ?: "Unknown"
                    
                    _selectedPoint.value = PointDetails(
                        name = name,
                        x = geometry.x,
                        y = geometry.y,
                        spatialReference = srName
                    )
                    println("Point selected: $name at (${geometry.x}, ${geometry.y})")
                }
            } catch (e: Exception) {
                println("Error selecting point: ${e.message}")
            }
        }
    }

    fun selectLineFromFeature(feature: Feature) {
        viewModelScope.launch {
            try {
                val geometry = feature.geometry as? Polyline
                val name = feature.attributes["name"] as? String ?: "Unknown Line"
                
                if (geometry != null) {
                    // Calculate length using GeometryEngine
                    val length = com.arcgismaps.geometry.GeometryEngine.lengthGeodetic(
                        geometry,
                        com.arcgismaps.geometry.LinearUnit.meters
                    ) ?: 0.0
                    
                    var pointCount = 0
                    geometry.parts.forEach { part ->
                        pointCount += part.pointCount
                    }
                    
                    _selectedLine.value = LineDetails(
                        name = name,
                        length = length,
                        pointCount = pointCount
                    )
                    println("Line selected: $name, Length: $length m, Points: $pointCount")
                }
            } catch (e: Exception) {
                println("Error selecting line: ${e.message}")
            }
        }
    }

    fun selectPolygonFromFeature(feature: Feature) {
        viewModelScope.launch {
            try {
                val geometry = feature.geometry as? Polygon
                val name = feature.attributes["name"] as? String ?: "Unknown Polygon"
                
                if (geometry != null) {
                    // Calculate area and perimeter using GeometryEngine
                    val area = com.arcgismaps.geometry.GeometryEngine.areaGeodetic(
                        geometry,
                        com.arcgismaps.geometry.AreaUnit.squareMeters
                    ) ?: 0.0
                    
                    val perimeter = com.arcgismaps.geometry.GeometryEngine.lengthGeodetic(
                        geometry,
                        com.arcgismaps.geometry.LinearUnit.meters
                    ) ?: 0.0
                    
                    _selectedPolygon.value = PolygonDetails(
                        name = name,
                        area = area,
                        perimeter = perimeter
                    )
                    println("Polygon selected: $name, Area: $area m², Perimeter: $perimeter m")
                }
            } catch (e: Exception) {
                println("Error selecting polygon: ${e.message}")
            }
        }
    }

    fun clearSelection() {
        _selectedPoint.value = null
        _selectedLine.value = null
        _selectedPolygon.value = null
        println("Selection cleared")
    }

    override fun onCleared() {
        super.onCleared()
    }
}
