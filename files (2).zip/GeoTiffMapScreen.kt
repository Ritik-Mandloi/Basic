package com.example.arcgisapp

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.arcgismaps.data.Feature
import com.arcgismaps.geometry.GeometryType
import com.arcgismaps.geometry.Point
import com.arcgismaps.geometry.Polygon
import com.arcgismaps.geometry.Polyline
import com.arcgismaps.mapping.view.GeometryEditor
import com.arcgismaps.toolkit.geoviewcompose.MapView
import com.arcgismaps.toolkit.geoviewcompose.MapViewProxy
import kotlinx.coroutines.launch

enum class DrawingMode {
    NONE,
    POINT,
    LINE,
    POLYGON
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeoTiffMapScreen(viewModel: MapViewModel = viewModel()) {

    val mapViewProxy = remember { MapViewProxy() }
    val geometryEditor = remember { GeometryEditor() }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var showPoints by rememberSaveable { mutableStateOf(true) }
    var showLines by rememberSaveable { mutableStateOf(true) }
    var showPolygons by rememberSaveable { mutableStateOf(true) }
    var showRaster by rememberSaveable { mutableStateOf(true) }
    
    var drawingMode by rememberSaveable { mutableStateOf(DrawingMode.NONE) }

    val selectedPoint by viewModel.selectedPoint.collectAsState()
    val selectedLine by viewModel.selectedLine.collectAsState()
    val selectedPolygon by viewModel.selectedPolygon.collectAsState()

    // Update layer visibility
    LaunchedEffect(showPoints, showLines, showPolygons, showRaster) {
        viewModel.pointLayer.isVisible = showPoints
        viewModel.lineLayer.isVisible = showLines
        viewModel.polygonLayer.isVisible = showPolygons
        viewModel.overlayRasterLayer.isVisible = showRaster
    }

    // Handle drawing mode
    LaunchedEffect(drawingMode) {
        when (drawingMode) {
            DrawingMode.POINT -> {
                geometryEditor.start(GeometryType.Point)
                println("🎨 Geometry editor started for Point")
            }
            DrawingMode.LINE -> {
                geometryEditor.start(GeometryType.Polyline)
                println("🎨 Geometry editor started for Polyline")
            }
            DrawingMode.POLYGON -> {
                geometryEditor.start(GeometryType.Polygon)
                println("🎨 Geometry editor started for Polygon")
            }
            DrawingMode.NONE -> {
                if (geometryEditor.isStarted.value) {
                    geometryEditor.stop()
                    println("🎨 Geometry editor stopped")
                }
            }
        }
    }

    // Monitor geometry editor for completed geometries
    LaunchedEffect(Unit) {
        geometryEditor.geometry.collect { geometry ->
            if (geometry != null && drawingMode != DrawingMode.NONE) {
                val timestamp = System.currentTimeMillis()
                
                scope.launch {
                    when (geometry) {
                        is Point -> {
                            println("📍 Point geometry created: (${geometry.x}, ${geometry.y})")
                            val feature = viewModel.addPointFromGeometry(
                                geometry, 
                                "Point_$timestamp"
                            )
                            if (feature != null) {
                                println("✅ Point feature added, clearing editor")
                                geometryEditor.clearGeometry()
                            } else {
                                println("❌ Failed to add point feature")
                            }
                        }
                        is Polyline -> {
                            println("📈 Polyline geometry created with ${geometry.parts.size} parts")
                            val feature = viewModel.addLineFromGeometry(
                                geometry,
                                "Line_$timestamp"
                            )
                            if (feature != null) {
                                println("✅ Line feature added, exiting drawing mode")
                                geometryEditor.clearGeometry()
                                drawingMode = DrawingMode.NONE
                            }
                        }
                        is Polygon -> {
                            println("⬟ Polygon geometry created with ${geometry.parts.size} parts")
                            val feature = viewModel.addPolygonFromGeometry(
                                geometry,
                                "Polygon_$timestamp"
                            )
                            if (feature != null) {
                                println("✅ Polygon feature added, exiting drawing mode")
                                geometryEditor.clearGeometry()
                                drawingMode = DrawingMode.NONE
                            }
                        }
                    }
                }
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = false,
        drawerContent = {
            DrawerMenuContent(
                showPoints = showPoints,
                showLines = showLines,
                showPolygons = showPolygons,
                showRaster = showRaster,
                onPointsChanged = { showPoints = it },
                onLinesChanged = { showLines = it },
                onPolygonsChanged = { showPolygons = it },
                onRasterChanged = { showRaster = it },
                onDrawPoint = {
                    drawingMode = if (drawingMode == DrawingMode.POINT) {
                        DrawingMode.NONE
                    } else {
                        DrawingMode.POINT
                    }
                    scope.launch { drawerState.close() }
                },
                onDrawLine = {
                    drawingMode = if (drawingMode == DrawingMode.LINE) {
                        DrawingMode.NONE
                    } else {
                        DrawingMode.LINE
                    }
                    scope.launch { drawerState.close() }
                },
                onDrawPolygon = {
                    drawingMode = if (drawingMode == DrawingMode.POLYGON) {
                        DrawingMode.NONE
                    } else {
                        DrawingMode.POLYGON
                    }
                    scope.launch { drawerState.close() }
                },
                drawingMode = drawingMode
            )
        }
    ) {
        Scaffold(
            floatingActionButton = {
                FloatingActionButton(
                    onClick = {
                        scope.launch {
                            if (drawerState.isClosed) {
                                drawerState.open()
                            } else {
                                drawerState.close()
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Menu,
                        contentDescription = "Open menu"
                    )
                }
            },
            floatingActionButtonPosition = FabPosition.Start
        ) { padding ->
            Box(modifier = Modifier.fillMaxSize()) {
                MapView(
                    arcGISMap = viewModel.arcGISMap,
                    modifier = Modifier.fillMaxSize(),
                    mapViewProxy = mapViewProxy,
                    geometryEditor = geometryEditor,
                    onSingleTapConfirmed = { event ->
                        if (drawingMode == DrawingMode.NONE) {
                            scope.launch {
                                try {
                                    println("\n🔍 ========== TAP DETECTED ==========")
                                    println("🔍 Tap at: (${event.screenCoordinate.x}, ${event.screenCoordinate.y})")
                                    println("🔍 Map point: ${event.mapPoint}")
                                    
                                    var featureFound = false
                                    
                                    // Check if point layer is visible
                                    println("🔍 Point layer visible: ${viewModel.pointLayer.isVisible}")
                                    println("🔍 Point layer opacity: ${viewModel.pointLayer.opacity}")
                                    
                                    // Try points first (highest priority)
                                    if (showPoints) {
                                        println("🔍 Identifying points...")
                                        try {
                                            val pointResults = mapViewProxy.identify(
                                                layer = viewModel.pointLayer,
                                                screenCoordinate = event.screenCoordinate,
                                                tolerance = 22.0,
                                                returnPopupsOnly = false
                                            ).getOrNull()
                                            
                                            println("🔍 Point results: ${pointResults?.geoElements?.size ?: 0} features")
                                            
                                            if (pointResults != null && pointResults.geoElements.isNotEmpty()) {
                                                println("✅ Found ${pointResults.geoElements.size} point(s)")
                                                val feature = pointResults.geoElements.first() as? Feature
                                                if (feature != null) {
                                                    println("✅ Point feature attributes: ${feature.attributes}")
                                                    println("✅ Point geometry: ${feature.geometry}")
                                                    viewModel.clearSelection()
                                                    viewModel.selectPointFromFeature(feature)
                                                    featureFound = true
                                                }
                                            }
                                        } catch (e: Exception) {
                                            println("❌ Point identify error: ${e.message}")
                                            e.printStackTrace()
                                        }
                                    }
                                    
                                    if (featureFound) {
                                        println("🔍 ===================================\n")
                                        return@launch
                                    }
                                    
                                    // Try lines
                                    if (showLines) {
                                        println("🔍 Identifying lines...")
                                        try {
                                            val lineResults = mapViewProxy.identify(
                                                layer = viewModel.lineLayer,
                                                screenCoordinate = event.screenCoordinate,
                                                tolerance = 22.0,
                                                returnPopupsOnly = false
                                            ).getOrNull()
                                            
                                            println("🔍 Line results: ${lineResults?.geoElements?.size ?: 0} features")
                                            
                                            if (lineResults != null && lineResults.geoElements.isNotEmpty()) {
                                                println("✅ Found ${lineResults.geoElements.size} line(s)")
                                                val feature = lineResults.geoElements.first() as? Feature
                                                if (feature != null) {
                                                    viewModel.clearSelection()
                                                    viewModel.selectLineFromFeature(feature)
                                                    featureFound = true
                                                }
                                            }
                                        } catch (e: Exception) {
                                            println("❌ Line identify error: ${e.message}")
                                            e.printStackTrace()
                                        }
                                    }
                                    
                                    if (featureFound) {
                                        println("🔍 ===================================\n")
                                        return@launch
                                    }
                                    
                                    // Try polygons
                                    if (showPolygons) {
                                        println("🔍 Identifying polygons...")
                                        try {
                                            val polygonResults = mapViewProxy.identify(
                                                layer = viewModel.polygonLayer,
                                                screenCoordinate = event.screenCoordinate,
                                                tolerance = 22.0,
                                                returnPopupsOnly = false
                                            ).getOrNull()
                                            
                                            println("🔍 Polygon results: ${polygonResults?.geoElements?.size ?: 0} features")
                                            
                                            if (polygonResults != null && polygonResults.geoElements.isNotEmpty()) {
                                                println("✅ Found ${polygonResults.geoElements.size} polygon(s)")
                                                val feature = polygonResults.geoElements.first() as? Feature
                                                if (feature != null) {
                                                    viewModel.clearSelection()
                                                    viewModel.selectPolygonFromFeature(feature)
                                                    featureFound = true
                                                }
                                            }
                                        } catch (e: Exception) {
                                            println("❌ Polygon identify error: ${e.message}")
                                            e.printStackTrace()
                                        }
                                    }
                                    
                                    if (!featureFound) {
                                        println("ℹ️ No features found at tap location")
                                        viewModel.clearSelection()
                                    }
                                    
                                    println("🔍 ===================================\n")
                                    
                                } catch (e: Exception) {
                                    println("❌ Exception during identify: ${e.message}")
                                    e.printStackTrace()
                                    viewModel.clearSelection()
                                }
                            }
                        }
                    }
                )
                
                // Point Details Card
                AnimatedVisibility(
                    visible = selectedPoint != null,
                    enter = slideInHorizontally(initialOffsetX = { it }),
                    exit = slideOutHorizontally(targetOffsetX = { it }),
                    modifier = Modifier.align(Alignment.CenterEnd)
                ) {
                    selectedPoint?.let { point ->
                        PointDetailsCard(
                            pointDetails = point,
                            onClose = { viewModel.clearSelection() }
                        )
                    }
                }
                
                // Line Details Card
                AnimatedVisibility(
                    visible = selectedLine != null,
                    enter = slideInHorizontally(initialOffsetX = { it }),
                    exit = slideOutHorizontally(targetOffsetX = { it }),
                    modifier = Modifier.align(Alignment.CenterEnd)
                ) {
                    selectedLine?.let { line ->
                        LineDetailsCard(
                            lineDetails = line,
                            onClose = { viewModel.clearSelection() }
                        )
                    }
                }
                
                // Polygon Details Card
                AnimatedVisibility(
                    visible = selectedPolygon != null,
                    enter = slideInHorizontally(initialOffsetX = { it }),
                    exit = slideOutHorizontally(targetOffsetX = { it }),
                    modifier = Modifier.align(Alignment.CenterEnd)
                ) {
                    selectedPolygon?.let { polygon ->
                        PolygonDetailsCard(
                            polygonDetails = polygon,
                            onClose = { viewModel.clearSelection() }
                        )
                    }
                }
                
                // Drawing mode indicator
                when (drawingMode) {
                    DrawingMode.POINT -> {
                        DrawingIndicator(
                            icon = Icons.Rounded.Place,
                            text = "Tap map to add point",
                            onClose = { drawingMode = DrawingMode.NONE },
                            modifier = Modifier.align(Alignment.TopCenter)
                        )
                    }
                    DrawingMode.LINE -> {
                        DrawingIndicator(
                            icon = Icons.Rounded.Timeline,
                            text = "Tap to add vertices, double-tap to finish",
                            onClose = { drawingMode = DrawingMode.NONE },
                            modifier = Modifier.align(Alignment.TopCenter)
                        )
                    }
                    DrawingMode.POLYGON -> {
                        DrawingIndicator(
                            icon = Icons.Rounded.Polyline,
                            text = "Tap to add vertices, double-tap to finish",
                            onClose = { drawingMode = DrawingMode.NONE },
                            modifier = Modifier.align(Alignment.TopCenter)
                        )
                    }
                    DrawingMode.NONE -> { /* No indicator */ }
                }
            }
        }
    }
}

@Composable
fun DrawingIndicator(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.padding(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            IconButton(onClick = onClose) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Exit drawing mode",
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }
}

@Composable
fun PointDetailsCard(
    pointDetails: PointDetails,
    onClose: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .padding(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            DetailCardHeader(title = "Point Details", onClose = onClose)
            
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(16.dp))
            
            DetailRow(Icons.Rounded.Label, "Name", pointDetails.name)
            Spacer(modifier = Modifier.height(12.dp))
            DetailRow(Icons.Rounded.Public, "Latitude", "%.6f°".format(pointDetails.y))
            Spacer(modifier = Modifier.height(12.dp))
            DetailRow(Icons.Rounded.Public, "Longitude", "%.6f°".format(pointDetails.x))
            
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(12.dp))
            
            Text("Spatial Reference", style = MaterialTheme.typography.labelMedium)
            Text(pointDetails.spatialReference, style = MaterialTheme.typography.bodyMedium)
            
            Spacer(modifier = Modifier.height(12.dp))
            Text("Full Coordinates", style = MaterialTheme.typography.labelMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text("X: ${pointDetails.x}", 
                style = MaterialTheme.typography.bodySmall,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
            Text("Y: ${pointDetails.y}", 
                style = MaterialTheme.typography.bodySmall,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        }
    }
}

@Composable
fun LineDetailsCard(
    lineDetails: LineDetails,
    onClose: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .padding(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            DetailCardHeader(title = "Line Details", onClose = onClose)
            
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(16.dp))
            
            DetailRow(Icons.Rounded.Label, "Name", lineDetails.name)
            Spacer(modifier = Modifier.height(12.dp))
            DetailRow(Icons.Rounded.Straighten, "Length", "%.2f m".format(lineDetails.length))
            Spacer(modifier = Modifier.height(12.dp))
            DetailRow(Icons.Rounded.Place, "Vertices", lineDetails.pointCount.toString())
            
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(12.dp))
            
            Text("Length in kilometers", style = MaterialTheme.typography.labelMedium)
            Text("%.3f km".format(lineDetails.length / 1000), 
                style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
fun PolygonDetailsCard(
    polygonDetails: PolygonDetails,
    onClose: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .padding(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            DetailCardHeader(title = "Polygon Details", onClose = onClose)
            
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(16.dp))
            
            DetailRow(Icons.Rounded.Label, "Name", polygonDetails.name)
            Spacer(modifier = Modifier.height(12.dp))
            DetailRow(Icons.Rounded.SquareFoot, "Area", "%.2f m²".format(polygonDetails.area))
            Spacer(modifier = Modifier.height(12.dp))
            DetailRow(Icons.Rounded.Straighten, "Perimeter", "%.2f m".format(polygonDetails.perimeter))
            
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(12.dp))
            
            Text("Area in hectares", style = MaterialTheme.typography.labelMedium)
            Text("%.4f ha".format(polygonDetails.area / 10000), 
                style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
fun DetailCardHeader(title: String, onClose: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.primary
        )
        IconButton(onClick = onClose) {
            Icon(imageVector = Icons.Rounded.Close, contentDescription = "Close")
        }
    }
}

@Composable
fun DetailRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            modifier = Modifier.size(20.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(text = value, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
fun DrawerMenuContent(
    showPoints: Boolean,
    showLines: Boolean,
    showPolygons: Boolean,
    showRaster: Boolean,
    onPointsChanged: (Boolean) -> Unit,
    onLinesChanged: (Boolean) -> Unit,
    onPolygonsChanged: (Boolean) -> Unit,
    onRasterChanged: (Boolean) -> Unit,
    onDrawPoint: () -> Unit,
    onDrawLine: () -> Unit,
    onDrawPolygon: () -> Unit,
    drawingMode: DrawingMode
) {
    ModalDrawerSheet(
        modifier = Modifier
            .fillMaxHeight()
            .width(320.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(
                text = "Map Controls",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(vertical = 16.dp)
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            DrawingToolsSection(
                onDrawPoint = onDrawPoint,
                onDrawLine = onDrawLine,
                onDrawPolygon = onDrawPolygon,
                drawingMode = drawingMode
            )

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            LayerVisibilitySection(
                showPoints = showPoints,
                showLines = showLines,
                showPolygons = showPolygons,
                showRaster = showRaster,
                onPointsChanged = onPointsChanged,
                onLinesChanged = onLinesChanged,
                onPolygonsChanged = onPolygonsChanged,
                onRasterChanged = onRasterChanged
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun DrawingToolsSection(
    onDrawPoint: () -> Unit,
    onDrawLine: () -> Unit,
    onDrawPolygon: () -> Unit,
    drawingMode: DrawingMode
) {
    Column {
        Text(
            text = "Drawing Tools",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        DrawingToolButton(
            icon = Icons.Rounded.Place,
            label = "Draw Point",
            description = if (drawingMode == DrawingMode.POINT) "Click to stop" else "Add a point",
            onClick = onDrawPoint,
            isActive = drawingMode == DrawingMode.POINT
        )

        Spacer(modifier = Modifier.height(8.dp))

        DrawingToolButton(
            icon = Icons.Rounded.Timeline,
            label = "Draw Line",
            description = if (drawingMode == DrawingMode.LINE) "Click to stop" else "Add a polyline",
            onClick = onDrawLine,
            isActive = drawingMode == DrawingMode.LINE
        )

        Spacer(modifier = Modifier.height(8.dp))

        DrawingToolButton(
            icon = Icons.Rounded.Polyline,
            label = "Draw Polygon",
            description = if (drawingMode == DrawingMode.POLYGON) "Click to stop" else "Add a polygon",
            onClick = onDrawPolygon,
            isActive = drawingMode == DrawingMode.POLYGON
        )
    }
}

@Composable
fun DrawingToolButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    description: String,
    onClick: () -> Unit,
    isActive: Boolean = false
) {
    OutlinedCard(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = if (isActive) {
            CardDefaults.outlinedCardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
        } else {
            CardDefaults.outlinedCardColors()
        }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                modifier = Modifier.size(32.dp),
                tint = if (isActive) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.primary
                }
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (isActive) {
                        MaterialTheme.colorScheme.onPrimaryContainer
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    }
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isActive) {
                        MaterialTheme.colorScheme.onPrimaryContainer
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
            }
        }
    }
}

@Composable
fun LayerVisibilitySection(
    showPoints: Boolean,
    showLines: Boolean,
    showPolygons: Boolean,
    showRaster: Boolean,
    onPointsChanged: (Boolean) -> Unit,
    onLinesChanged: (Boolean) -> Unit,
    onPolygonsChanged: (Boolean) -> Unit,
    onRasterChanged: (Boolean) -> Unit
) {
    Column {
        Text(
            text = "Layer Visibility",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        LayerToggleRow(Icons.Rounded.Place, "Points Layer", showPoints, onPointsChanged)
        LayerToggleRow(Icons.Rounded.Timeline, "Lines Layer", showLines, onLinesChanged)
        LayerToggleRow(Icons.Rounded.Polyline, "Polygons Layer", showPolygons, onPolygonsChanged)
        
        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
        
        LayerToggleRow(Icons.Rounded.Layers, "Raster Overlay", showRaster, onRasterChanged)
    }
}

@Composable
fun LayerToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            modifier = Modifier.size(24.dp),
            tint = if (checked) MaterialTheme.colorScheme.primary 
                   else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.weight(1f)
        )
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
